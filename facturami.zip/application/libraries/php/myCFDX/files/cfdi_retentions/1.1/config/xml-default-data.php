<?php

return array(

	"xmlns:retenciones"=>"http://www.sat.gob.mx/esquemas/retencionpago/1",
	"xmlns:xs"=>"http://www.w3.org/2001/XMLSchema-instance", 
	"xmlns:premios"=>"http://www.sat.gob.mx/esquemas/retencionpago/1/premios"

	// "xsi:schemaLocation"=>"http://www.sat.gob.mx/esquemas/retencionpago/1 http://www.sat.gob.mx/esquemas/retencionpago/1/retencionpagov1.xsd http://www.sat.gob.mx/dividendos http://www.sat.gob.mx/sitio_internet/retencionpago/premios/premios.xsd"

);

?>